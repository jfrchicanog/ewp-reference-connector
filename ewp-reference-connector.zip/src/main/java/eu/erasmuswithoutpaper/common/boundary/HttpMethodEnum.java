package eu.erasmuswithoutpaper.common.boundary;

public enum HttpMethodEnum {
    GET, POST, PUT
}
