package eu.erasmuswithoutpaper.iia.common;

public enum IiaTaskEnum {
    CREATED,
    UPDATED,
    APPROVED,
    MODIFY,
    DELETED,
    REVERTED,
    TERMINATED
}
