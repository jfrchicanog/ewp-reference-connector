package eu.erasmuswithoutpaper.iia.entity;

//import lombok.*;

import javax.persistence.*;
import java.math.BigInteger;
import java.util.Objects;

/*@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
@Entity*/
public class MobilitiesPerYear {
/*
    @Id
    @GeneratedValue(generator="system-uuid")
    String id;

    private BigInteger value;
    private Boolean notYetDefined;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MobilitiesPerYear that = (MobilitiesPerYear) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }*/
}
