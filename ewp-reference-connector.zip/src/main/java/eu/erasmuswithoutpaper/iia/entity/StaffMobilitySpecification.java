package eu.erasmuswithoutpaper.iia.entity;

//import lombok.*;

import javax.persistence.*;
import java.math.BigDecimal;

/*@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
@Entity*/
public class StaffMobilitySpecification /*extends MobilitySpecification */{
/*
    private BigDecimal totalDaysPerYear;

    @ManyToOne(cascade = CascadeType.DETACH, fetch = FetchType.LAZY)
    @JoinColumn(name = "STAFFTEACHER_CC_ID", referencedColumnName = "ID")
    private CooperationCondition_NEW staffTeacherMobilitySpecCC;

    @ManyToOne(cascade = CascadeType.DETACH, fetch = FetchType.LAZY)
    @JoinColumn(name = "STAFFTRAINING_CC_ID", referencedColumnName = "ID")
    private CooperationCondition_NEW staffTrainingMobilitySpecCC;*/
}
