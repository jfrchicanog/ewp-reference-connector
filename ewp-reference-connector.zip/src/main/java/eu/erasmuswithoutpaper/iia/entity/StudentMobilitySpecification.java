package eu.erasmuswithoutpaper.iia.entity;

//import lombok.*;

import javax.persistence.*;
import java.math.BigDecimal;

/*@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
@Entity*/
public class StudentMobilitySpecification /*extends MobilitySpecification */{

    /*private BigDecimal totalMonthsPerYear;
    private Boolean blended;
    @Lob
    private Byte[] eqfLevel;

    @ManyToOne(cascade = CascadeType.DETACH, fetch = FetchType.LAZY)
    @JoinColumn(name = "STUDENSTUDIES_CC_ID", referencedColumnName = "ID")
    private CooperationCondition
    _NEW studentStudiesMobilitySpecCC;

    @ManyToOne(cascade = CascadeType.DETACH, fetch = FetchType.LAZY)
    @JoinColumn(name = "STUDENTTRAINEESHIP_CC_ID", referencedColumnName = "ID")
    private CooperationCondition_NEW studentTraineeshipMobilitySpecCC;*/
}
